//
//  NFNetworkConfig.h
//  NewsFeedsSDK
//
//  Created by shoulei ma on 2017/8/16.
//  Copyright © 2017年 NetEase. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @YDNetworkDevEnv     开发环境
 @YDNetworkOnlineEnv  线上环境
 @YDNetworkPreEnv     预发布环境
 @YDNETworkTestEnv    测试环境
 */
typedef NS_ENUM(NSInteger, NFSDKNetworkHostEnv) {
    /// 开发环境
    NFSDKNetworkDevEnv,
    /// 线上环境
    NFSDKNetworkOnlineEnv,
    /// 预发布环境
    NFSDKNetworkPreEnv,
    /// 测试环境
    NFSDKNetworkQAEnv,
};

@interface NFSDKNetworkConfig : NSObject

+ (NFSDKNetworkHostEnv)hostEnv;
+ (NSString *)getBaseUrlString;

@end
