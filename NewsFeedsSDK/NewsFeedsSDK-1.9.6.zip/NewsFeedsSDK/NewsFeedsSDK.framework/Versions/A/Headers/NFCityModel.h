//
//  NFCityModel.h
//  NewsFeedsSDK
//
//  Created by Jingjq on 2018/8/9.
//

#import <Foundation/Foundation.h>

@interface NFCityModelItem : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, strong) NSArray <NFCityModelItem *> *children;
@property (nonatomic, assign) BOOL isCurrentCity;
@property (nonatomic, assign) BOOL isSpread;
@property (nonatomic, assign) BOOL isChild;

@end

@interface NFCityModel : NSObject

@property (nonatomic, strong) NSArray <NFCityModelItem *>*locations;
@property (nonatomic, copy) NSString *ip;
@property (nonatomic, copy) NSString *city;

@end

@interface NFCityResponse : NSObject

@property (nonatomic, copy)     NSString *requestId;
@property (nonatomic, assign)   NSInteger code;
@property (nonatomic, copy)     NSString *message;
@property (nonatomic, strong)   NFCityModel *data;

@end
